<nav class="navbar navbar-expand-sm navbar-dark bg-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="index.php"><b>Hotel California</b></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
        <li class="nav-item">
          <a class="nav-link" href="rezerwacje.php">Rezerwacje</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Pobyt</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Goście</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="javascript:void(0)">Użytkownicy</a>
        </li>
      </ul>
    </div>
        <div class="container-fluid">
        <ul class="nav justify-content-end">
        <li class="nav-item">
        <a class="nav-link" href="logowanie.php">Logowanie</a>
        </li>
        <li class="nav-item">
        <a class="navbar-brand" href="#">
        <img src="hotel.png" alt="Avatar Logo" style="width:35px;"> 
        </a>
        </li>
        </ul>
        </div>
  </div>
</nav>